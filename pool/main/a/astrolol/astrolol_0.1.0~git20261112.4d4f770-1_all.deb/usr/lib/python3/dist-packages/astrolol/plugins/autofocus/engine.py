"""Autofocus engine: orchestrates the V-curve measurement sequence.

Algorithm
---------
1. Record current focuser position as the centre.
2. Generate ``2 * num_steps + 1`` sample positions evenly spaced by ``step_size``
   (clamped to ≥ 0).
3. For each position: move focuser → expose → detect stars → measure median FWHM.
4. Refit the parabola after every data point so the UI can show a live curve.
5. Move to the parabola minimum (or to the measured minimum if the fit fails).
"""
from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

import structlog

from astrolol.config.settings import settings
from astrolol.core.events import EventBus
from astrolol.core.mem_guard import mem_guard
from astrolol.devices.base.models import ExposureParams
from astrolol.devices.manager import DeviceManager
from astrolol.plugins.autofocus.algorithms import fit_hyperbola, fit_minimum, fit_parabola, fit_r_squared
from astrolol.plugins.autofocus.models import (
    AutofocusAbortedEvent,
    AutofocusCompletedEvent,
    AutofocusConfig,
    AutofocusDataPointEvent,
    AutofocusFailedEvent,
    AutofocusRun,
    AutofocusSettings,
    AutofocusStartedEvent,
    CurveFit,
    DoubtPolicy,
    FocusAttempt,
    FocusDataPoint,
    FocusQuality,
    StarInfo,
)
from astrolol.plugins.autofocus.quality import assess, edge_direction, mismatched
from astrolol.plugins.autofocus.star_detector import detect_stars

logger = structlog.get_logger()

_MOVE_TIMEOUT = 120.0   # seconds to wait for a single focuser move
_EXPOSE_TIMEOUT = 300.0  # seconds to wait for a single exposure


def _annotate_preview(
    jpeg_path: str,
    stars: list[dict],
    fits_w: int,
    fits_h: int,
) -> None:
    """Draw green circles on the JPEG for each detected star.

    Star coordinates are in FITS pixel space; the JPEG may have been
    downscaled by fits_to_jpeg, so we apply the same scale factor.
    """
    from PIL import Image, ImageDraw
    # fits_to_jpeg/fits_to_jpeg_linear save grayscale ("L" mode) JPEGs. Drawing a
    # colour outline directly on an "L" image silently converts it to a grayscale
    # luminance value (PIL has no color to draw with), which is why the circles
    # rendered as near-black regardless of the outline colour requested below.
    img = Image.open(jpeg_path).convert("RGB")
    jpeg_w, jpeg_h = img.size
    sx = jpeg_w / fits_w if fits_w else 1.0
    sy = jpeg_h / fits_h if fits_h else 1.0
    draw = ImageDraw.Draw(img)
    for star in stars:
        cx = star["x"] * sx
        cy = star["y"] * sy
        r  = star["fwhm"] * max(sx, sy) * 2.5
        # Bright magenta reads clearly against both dark sky and stretched star
        # cores (green/cyan tend to blend into star halos); width=1 keeps the
        # circle from eating into small/faint stars.
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline="#ff2ec8", width=1)
    img.save(jpeg_path, format="JPEG", quality=90)


def _read_fits_shape(fits_path: str) -> tuple[int, int]:
    """Return (width, height) from the FITS header, without reading the pixels."""
    try:
        from astropy.io import fits
        with fits.open(fits_path, memmap=True, do_not_scale_image_data=True) as hdul:
            header = hdul[0].header
            return int(header["NAXIS1"]), int(header["NAXIS2"])
    except Exception:
        return 0, 0


# Sweeps added, at most, when the minimum lies beyond the end of the swept range (a focus that
# moved a lot, e.g. after a filter change): each one is centred past the end where the
# measurements were still improving, and its points join those already measured.
_MAX_RECENTRES = 2
_MAX_REFERENCE_STARS = 30  # strongest stars of the reference frame kept by lock_stars; the faint tail is mostly noise


def _action(config: AutofocusConfig, cause: str) -> str:
    return getattr(config, f"on_{cause}")


def next_sweep(run: AutofocusRun) -> list[int] | None:
    """Positions of one more sweep when the minimum is beyond the swept range, else None.

    Centred half a sweep past the end the measurements point to, on the grid already used, and
    without the positions already measured. Listed from the old end outwards.
    """
    direction = edge_direction(run.data_points, run.curve_fit)
    if direction == 0:
        return None
    config = run.config
    measured = {dp.position for dp in run.data_points}
    end = max(measured) if direction > 0 else min(measured)
    if run.curve_fit is not None:
        # The fit says where the minimum is: sweep around it, on the grid already used.
        centre = end + round((run.curve_fit.optimal_position - end) / config.step_size) * config.step_size
    else:
        centre = end + direction * round(config.num_steps / 2) * config.step_size
    wanted = {
        max(0, centre + (i - config.num_steps) * config.step_size)
        for i in range(2 * config.num_steps + 1)
    } - measured
    if not wanted:
        return None
    return sorted(wanted, key=lambda p: (p - end) * direction)


def _centre_first(sweep: list[int]) -> list[int]:
    """*sweep* with its middle position first, the others keeping their order."""
    if len(sweep) < 3:
        return list(sweep)
    mid = len(sweep) // 2
    return [sweep[mid], *sweep[:mid], *sweep[mid + 1:]]


class AutofocusEngine:
    """Manages one autofocus run at a time."""

    def __init__(
        self,
        event_bus: EventBus,
        device_manager: DeviceManager,
        settings_provider: Callable[[], AutofocusSettings] | None = None,
    ) -> None:
        self._bus = event_bus
        self._device_manager = device_manager
        self._settings_provider = settings_provider or AutofocusSettings
        self._current_run: AutofocusRun | None = None
        self._task: asyncio.Task | None = None
        # Maps step number (1-indexed) → {"auto": path, "linear": path}
        self._preview_paths: dict[int, dict[str, str]] = {}
        # Stars of the first step that found any, kept to measure again at every later step (lock_stars).
        self._reference_stars: list[dict] | None = None

    @property
    def current_run(self) -> AutofocusRun | None:
        return self._current_run

    def preview_path(self, step: int, stretch: str = "auto") -> str | None:
        return self._preview_paths.get(step, {}).get(stretch)

    async def start(self, config: AutofocusConfig) -> AutofocusRun:
        if self._task is not None and not self._task.done():
            raise ValueError("Autofocus is already running. Call abort() first.")

        total_steps = config.num_steps * 2 + 1
        run = AutofocusRun(config=config, status="running", total_steps=total_steps)
        self._current_run = run
        self._preview_paths.clear()

        self._task = asyncio.create_task(self._run(run), name=f"autofocus_{run.id}")
        return run

    async def focus(self, camera_id: str, focuser_id: str) -> AutofocusRun:
        """Run autofocus with the saved autofocus settings and wait for the result.

        For automation (the sequencer): the filter is left as it is. Cancelling the caller
        aborts the run (the focuser returns to where it started). Raises ValueError when a
        run is already in progress; a failed run is returned with status "failed".
        """
        s = self._settings_provider()
        config = AutofocusConfig(
            camera_id=camera_id,
            focuser_id=focuser_id,
            step_size=s.step_size,
            num_steps=s.num_steps,
            exposure_time=s.exposure_time,
            binning=s.binning,
            gain=s.gain,
            fit_algo=s.fit_algo,
            metric=s.metric,
            lock_stars=s.lock_stars,
            **s.model_dump(include=set(DoubtPolicy.model_fields)),
        )
        run = await self.start(config)
        task = self._task
        assert task is not None
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            await self.abort()
            raise
        return run

    async def abort(self) -> None:
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    # ── Internal ──────────────────────────────────────────────────────────────

    async def _run(self, run: AutofocusRun) -> None:
        config = run.config
        preview_dir = Path(settings.images_dir) / "autofocus" / run.id
        preview_dir.mkdir(parents=True, exist_ok=True)

        restore_to: int | None = None
        try:
            camera = self._device_manager.get_camera(config.camera_id)
            focuser = self._device_manager.get_focuser(config.focuser_id)

            # Optional: change filter before starting
            if config.filter_slot is not None:
                await self._select_filter(config.filter_slot, config.filter_wheel_id)

            # Determine starting position. restore_to is always the position the
            # focuser was at *before this run touched it* — even when a manual
            # start_position is given — so a failed/aborted run always lands back
            # where the user actually was, not at the requested sweep centre.
            focuser_status = await focuser.get_status()
            restore_to = focuser_status.position or 0
            run.initial_position = restore_to
            start_pos = restore_to

            if config.start_position is not None:
                logger.info("autofocus.moving_to_start_position", position=config.start_position)
                await asyncio.wait_for(focuser.move_to(config.start_position), timeout=_MOVE_TIMEOUT)
                start_pos = config.start_position

            positions = [
                start_pos + (i - config.num_steps) * config.step_size
                for i in range(run.total_steps)
            ]
            positions = [max(0, p) for p in positions]

            await self._bus.publish(AutofocusStartedEvent(
                run_id=run.id,
                camera_id=config.camera_id,
                focuser_id=config.focuser_id,
                total_steps=run.total_steps,
            ))

            exposure = config.exposure_time
            retries = 0
            sweep = positions
            while True:
                run.exposure_time = exposure
                params = ExposureParams(
                    duration=exposure,
                    gain=config.gain,
                    binning=config.binning,
                    frame_type="light",
                )
                # When lock_stars is set, the sweep starts at its centre (the best guess at
                # focus, where the real stars are brightest and noise is least likely to pass
                # for stars); the strongest stars of the first step that detects any are frozen
                # and reused as the preferred population for every later step —
                # a step where none of these stars can be matched reports no stars.
                self._reference_stars = None

                for pass_no in range(1 + _MAX_RECENTRES):
                    for position in (_centre_first(sweep) if config.lock_stars and pass_no == 0 else sweep):
                        await self._measure_step(run, camera, focuser, params, exposure, position, preview_dir)

                    self._refit_curve(run)
                    further = next_sweep(run) if pass_no < _MAX_RECENTRES and config.on_edge == "retry" else None
                    if further is None:
                        break
                    logger.info(
                        "autofocus.recentring",
                        run_id=run.id, pass_no=pass_no + 2, positions=further,
                        reason="the minimum is not bracketed by the swept range",
                    )
                    run.total_steps += len(further)
                    sweep = further

                verdict = assess(run.data_points, run.curve_fit)
                failing = [c for c in verdict.causes if _action(config, c) == "fail"]
                if failing:
                    run.sky_problem = "few_stars" in failing
                    raise RuntimeError(
                        f"The focus curve is not reliable ({', '.join(failing)}) and this "
                        "autofocus is set to stop in that case."
                    )
                again = self._retry_sweep(run, verdict, exposure, retries)
                if again is None and config.verify_after_move and run.curve_fit is not None:
                    again = await self._verify(run, camera, focuser, params, exposure, verdict, retries)
                if again is None:
                    break
                retries += 1
                exposure, sweep = again
                run.total_steps = run.current_step + len(sweep)



            # ── Move to optimal position ───────────────────────────────────────
            self._refit_curve(run)

            valid = [dp for dp in run.data_points if dp.fwhm > 0 and dp.star_count > 0]
            if not valid:
                run.sky_problem = True
                raise RuntimeError(
                    "No stars detected at any focuser position. "
                    "Check exposure time, focus range, or star detection threshold."
                )

            if run.curve_fit is None:
                # No valid parabola/hyperbola fit — the sampled points don't form a
                # real V/U shape (too noisy, range too narrow, or genuinely no focus
                # minimum in range). Silently picking the lowest-FWHM sample here
                # would report success on data that isn't a real focus curve, so
                # this is treated as a failure and the focuser is restored below.
                direction = edge_direction(run.data_points, run.curve_fit)
                if direction != 0:
                    raise RuntimeError(
                        "The best focus is beyond the swept range (the sharpness was still "
                        f"improving towards {'higher' if direction > 0 else 'lower'} focuser positions "
                        "at the end of the last sweep). Start from a position closer to focus."
                    )
                raise RuntimeError(
                    "Focus curve did not fit a valid V shape — the measured points "
                    "don't converge to a minimum in range. Try a larger step size, "
                    "more steps, or a longer exposure."
                )

            optimal_position = max(0, round(run.curve_fit.optimal_position))
            run.optimal_position = optimal_position
            logger.info("autofocus.moving_to_optimal", position=optimal_position)
            await asyncio.wait_for(focuser.move_to(optimal_position), timeout=_MOVE_TIMEOUT)

            run.status = "completed"
            run.completed_at = datetime.now(timezone.utc)
            run.quality = assess(run.data_points, run.curve_fit)
            if run.expected_value is not None and mismatched(run.check_value, run.expected_value):
                run.quality.causes.append("mismatch")
                run.quality.verdict = "poor"

            await self._bus.publish(AutofocusCompletedEvent(
                run_id=run.id,
                optimal_position=optimal_position,
                quality=run.quality.verdict,
                causes=run.quality.causes,
            ))
            logger.info(
                "autofocus.completed",
                optimal_position=optimal_position,
                quality=run.quality.verdict,
                causes=run.quality.causes,
                **run.quality.metrics.model_dump(),
            )

        except asyncio.CancelledError:
            run.status = "aborted"
            run.completed_at = datetime.now(timezone.utc)
            await self._restore_focus(config.focuser_id, restore_to)
            await self._bus.publish(AutofocusAbortedEvent(run_id=run.id))
            logger.info("autofocus.aborted", run_id=run.id)
            raise

        except Exception as exc:
            run.status = "failed"
            run.error = str(exc)
            run.completed_at = datetime.now(timezone.utc)
            await self._restore_focus(config.focuser_id, restore_to)
            await self._bus.publish(AutofocusFailedEvent(run_id=run.id, reason=str(exc)))
            logger.error("autofocus.failed", run_id=run.id, error=str(exc), exc_info=True)

    async def _measure_step(
        self, run: AutofocusRun, camera, focuser, params: ExposureParams, exposure: float,  # noqa: ANN001
        position: int, preview_dir: Path,
    ) -> None:
        """Move to *position*, expose, measure the stars, and record the data point."""
        config = run.config
        run.current_step += 1

        # 1. Move focuser
        logger.info(
            "autofocus.moving",
            step=run.current_step,
            total=run.total_steps,
            position=position,
        )
        await asyncio.wait_for(focuser.move_to(position), timeout=_MOVE_TIMEOUT)
        # A focuser can stop a few steps short: the sample belongs to where it really is.
        reached = (await focuser.get_status()).position
        if reached is not None and reached != position:
            logger.info("autofocus.position_off_target", step=run.current_step, target=position, position=reached)
            position = reached

        # 2. Expose
        logger.info(
            "autofocus.exposing",
            step=run.current_step,
            duration=exposure,
        )
        image = await asyncio.wait_for(camera.expose(params), timeout=_EXPOSE_TIMEOUT)

        # Always derive dimensions from the FITS file itself so that
        # binning and subframe settings are reflected correctly.
        fits_w, fits_h = await asyncio.to_thread(_read_fits_shape, image.fits_path)
        run.image_width = fits_w or None
        run.image_height = fits_h or None

        # 3. Detect stars and measure sharpness (FWHM or HFD).
        # Wrapped in mem_guard so the heavy numpy/scipy work is
        # serialised with other memory-intensive tasks on low-RAM hosts.
        logger.info("autofocus.detecting_stars", step=run.current_step, metric=config.metric)
        async with mem_guard():
            fwhm, star_count, raw_stars = await detect_stars(
                image.fits_path,
                metric=config.metric,
                reference_stars=self._reference_stars if config.lock_stars else None,
            )

        if config.lock_stars and self._reference_stars is None and raw_stars:
            self._reference_stars = raw_stars[:_MAX_REFERENCE_STARS]

        run.latest_stars = [StarInfo(x=s["x"], y=s["y"], fwhm=s["fwhm"]) for s in raw_stars]

        # 4. Generate preview JPEGs (auto-stretch + linear) with star
        # circles burned in. Done AFTER star detection so circles are
        # always in the final file. _preview_paths is registered here
        # too, so the API endpoint never serves a circle-free version.
        auto_path = str(preview_dir / f"step_{run.current_step:02d}.jpg")
        linear_path = str(preview_dir / f"step_{run.current_step:02d}_linear.jpg")
        try:
            from astrolol.imaging.preview import load_preview_base, render_auto, render_linear

            def _render_step_previews(fits_path: Path, quality: int) -> None:
                base = load_preview_base(fits_path)  # one read for both previews
                render_auto(base, Path(auto_path), quality)
                render_linear(base, Path(linear_path), quality)

            async with mem_guard():
                await asyncio.to_thread(
                    _render_step_previews, Path(image.fits_path), settings.jpeg_quality,
                )
            if raw_stars:
                for p in (auto_path, linear_path):
                    await asyncio.to_thread(_annotate_preview, p, raw_stars, fits_w, fits_h)
            self._preview_paths[run.current_step] = {"auto": auto_path, "linear": linear_path}
        except Exception as exc:
            logger.warning("autofocus.preview_failed", step=run.current_step, error=str(exc))

        dp = FocusDataPoint(
            step=run.current_step,
            position=position,
            fwhm=fwhm,
            star_count=star_count,
        )
        run.data_points.append(dp)

        # 5. Refit the curve (live update for the UI)
        self._refit_curve(run)

        await self._bus.publish(AutofocusDataPointEvent(
            run_id=run.id,
            step=run.current_step,
            total_steps=run.total_steps,
            position=position,
            fwhm=fwhm,
            star_count=star_count,
        ))

        logger.info(
            "autofocus.data_point",
            step=run.current_step,
            position=position,
            metric=config.metric,
            value=round(fwhm, 2),
            stars=star_count,
        )


    def _retry_sweep(
        self, run: AutofocusRun, verdict: FocusQuality, exposure: float, retries: int,
    ) -> tuple[float, list[int]] | None:
        """Exposure and positions of a new sweep when the policy asks to measure again, else None.

        Only a flat, noisy or starless curve is measured again here (an edge is handled by
        sweeping further, in the sweep loop), with a longer exposure and a fresh set of
        samples centred on the best one; the sweep given up on is kept in run.attempts.
        """
        config = run.config
        causes = [c for c in verdict.causes if c != "edge" and _action(config, c) == "retry"]
        if not causes or retries >= config.max_retries:
            return None
        if verdict.metrics.valid_points == 0:
            return None   # no star at any position: a longer exposure will not change the sky
        longer = min(exposure * config.retry_exposure_factor, config.max_exposure)
        if longer < exposure * 1.05:
            logger.info("autofocus.no_retry", run_id=run.id, causes=causes, reason="longest exposure reached")
            return None
        valid = [dp for dp in run.data_points if dp.fwhm > 0 and dp.star_count > 0]
        best = min(valid, key=lambda dp: dp.fwhm).position
        return longer, self._resweep(run, verdict, exposure, retries, best, causes, longer)

    def _resweep(
        self, run: AutofocusRun, verdict: FocusQuality, exposure: float, retries: int,
        centre: int, causes: list[str], new_exposure: float,
    ) -> list[int]:
        """Put the sweep just made in run.attempts and return the positions of a fresh one around *centre*."""
        config = run.config
        positions = [max(0, centre + (i - config.num_steps) * config.step_size) for i in range(2 * config.num_steps + 1)]
        run.attempts.append(FocusAttempt(exposure_time=exposure, data_points=run.data_points, quality=verdict))
        run.data_points = []
        run.curve_fit = None
        logger.info(
            "autofocus.retrying",
            run_id=run.id, attempt=retries + 2, causes=causes, exposure=new_exposure, centre=centre,
        )
        return sorted(set(positions))

    async def _verify(
        self, run: AutofocusRun, camera, focuser, params: ExposureParams, exposure: float,  # noqa: ANN001
        verdict: FocusQuality, retries: int,
    ) -> tuple[float, list[int]] | None:
        """Take a frame at the fitted optimum and compare its sharpness with what the fit predicts.

        Not part of the curve. When the frame is clearly less sharp, the policy decides: keep
        (the run is flagged), stop, or sweep again around the optimum (same exposure).
        """
        config = run.config
        fit = run.curve_fit
        assert fit is not None
        optimal = max(0, round(fit.optimal_position))
        await asyncio.wait_for(focuser.move_to(optimal), timeout=_MOVE_TIMEOUT)
        image = await asyncio.wait_for(camera.expose(params), timeout=_EXPOSE_TIMEOUT)
        async with mem_guard():
            measured, star_count, _stars = await detect_stars(
                image.fits_path,
                metric=config.metric,
                reference_stars=self._reference_stars if config.lock_stars else None,
            )
        expected = fit_minimum(config.fit_algo, fit.a, fit.b, fit.c)
        run.check_value = measured if star_count > 0 else None
        run.expected_value = expected
        bad = mismatched(run.check_value, expected)
        logger.info(
            "autofocus.checked", run_id=run.id, position=optimal, measured=round(measured, 2),
            expected=round(expected, 2), stars=star_count, mismatch=bad,
        )
        if not bad:
            return None
        if config.on_mismatch == "fail":
            raise RuntimeError(
                f"The check frame at the result is not as sharp as the fit says "
                f"({measured:.2f} against {expected:.2f}) and this autofocus is set to stop in that case."
            )
        if config.on_mismatch == "retry" and retries < config.max_retries:
            return exposure, self._resweep(run, verdict, exposure, retries, optimal, ["mismatch"], exposure)
        return None

    async def _restore_focus(self, focuser_id: str, position: int | None) -> None:
        """After a failed or aborted run, put the focuser back where it started — the last
        good focus — instead of leaving it at the end of the sweep. Best effort."""
        if position is None:
            return
        try:
            focuser = self._device_manager.get_focuser(focuser_id)
            await asyncio.wait_for(focuser.move_to(position), timeout=_MOVE_TIMEOUT)
            logger.info("autofocus.focus_restored", position=position)
        except Exception as exc:
            logger.warning("autofocus.focus_restore_failed", position=position, error=str(exc))

    def _refit_curve(self, run: AutofocusRun) -> None:
        valid = [(dp.position, dp.fwhm) for dp in run.data_points if dp.fwhm > 0]
        if len(valid) < 3:
            return
        config = run.config
        if len(run.data_points) > 2 * config.num_steps + 1:
            # Extra sweeps leave the points lopsided around the minimum (a long arm on one side,
            # a short one on the other), which pulls a parabola towards the short side. Fit what
            # a sweep centred on the best sample would have measured.
            best = min(valid, key=lambda point: point[1])[0]
            valid = [(p, f) for p, f in valid if abs(p - best) <= config.num_steps * config.step_size]
            if len(valid) < 3:
                return
        fit_fn = fit_hyperbola if run.config.fit_algo == "hyperbola" else fit_parabola
        result = fit_fn([p for p, _ in valid], [f for _, f in valid])
        if result is not None:
            a, b, c, optimal = result
            r2 = fit_r_squared(
                run.config.fit_algo, a, b, c, [p for p, _ in valid], [f for _, f in valid],
            )
            run.curve_fit = CurveFit(a=a, b=b, c=c, optimal_position=optimal, r_squared=r2)
        else:
            # A fit that was valid on an earlier (smaller) subset of points can
            # stop being valid once more data arrives — e.g. a good-looking early
            # V shape gets swamped by noisy points later in the sweep. Without
            # this, run.curve_fit would keep reporting that stale early fit
            # (and its optimal_position) all the way to the end of the run.
            run.curve_fit = None

    async def _select_filter(self, slot: int, filter_wheel_id: str | None) -> None:
        """Move the requested filter wheel to the requested slot (best-effort).

        filter_wheel_id pins the specific wheel on this camera's optical path (resolved
        by the UI from the active profile's equipment tree). Without it, falls back to
        "the first connected filter wheel" — only correct when exactly one is connected.
        """
        try:
            if filter_wheel_id is not None:
                fw = self._device_manager.get_filter_wheel(filter_wheel_id)
            else:
                fw_devices = [d for d in self._device_manager.list_connected() if d["kind"] == "filter_wheel"]
                if not fw_devices:
                    logger.warning("autofocus.no_filter_wheel", requested_slot=slot)
                    return
                fw = self._device_manager.get_filter_wheel(fw_devices[0]["device_id"])
            await fw.select_filter(slot)
            logger.info("autofocus.filter_selected", slot=slot, filter_wheel_id=filter_wheel_id)
        except Exception as exc:
            logger.warning("autofocus.filter_select_failed", slot=slot, error=str(exc))
