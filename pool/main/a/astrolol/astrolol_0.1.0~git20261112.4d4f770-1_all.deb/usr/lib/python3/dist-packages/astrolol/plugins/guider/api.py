"""REST routes of the built-in guider."""

from __future__ import annotations

from typing import Literal

import structlog
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field, field_validator

from astrolol.core.guiding import (
    GuiderError,
    GuiderStatus,
    GuidingHealth,
    GuidingStats,
    SettleParams,
    require_active_guider,
)
from astrolol.plugins.guider.calibration import Calibration
from astrolol.imaging.darks import DarkInfo
from astrolol.plugins.guider.guider import BuiltinGuider, CalibrationAttempt, Prediction
from astrolol.plugins.guider.settings import GuiderSettings
from astrolol.plugins.guider.view import ViewInfo

logger = structlog.get_logger()
router = APIRouter(prefix="/plugins/guider", tags=["guider"])

# Actions are refused while another guiding plugin is the active one.
_ACTIVE = Depends(require_active_guider("guider"))


def _guider(request: Request) -> BuiltinGuider:
    return request.app.state.builtin_guider  # type: ignore[no-any-return]


def _conflict(exc: Exception) -> HTTPException:
    return HTTPException(status_code=409, detail=str(exc))


class MountReport(BaseModel):
    dec: float | None = None
    pier_side: str | None = None
    slewing: bool = False


class GuiderReport(BaseModel):
    status: GuiderStatus
    health: GuidingHealth
    last_minute: GuidingStats
    calibration: Calibration | None
    # The calibration as it applies where the mount points now (declination, pier side).
    active_calibration: Calibration | None = None
    calibration_attempt: CalibrationAttempt | None = None  # under way, or the last that failed
    darks: list[DarkInfo]
    dark_matches: bool = False  # a dark exists for the current exposure and gain
    pixel_scale_source: Literal["settings", "optics"] | None = None  # where status.pixel_scale comes from
    last_error: str | None = None  # why the last run ended, when it failed
    mount: MountReport | None = None
    preferred_star: tuple[float, float] | None = None
    prediction: Prediction | None = None


@router.get("/status", response_model=GuiderReport)
async def get_status(request: Request) -> GuiderReport:
    g = _guider(request)
    await g.refresh_pixel_scale(max_age=10.0)
    await g.refresh_mount()
    now = g.mark()
    m = g.mount
    return GuiderReport(
        status=g.status(),
        health=g.health(),
        last_minute=g.stats(now - 60, now),
        calibration=g.calibration,
        active_calibration=g.active_calibration,
        calibration_attempt=g.calibration_attempt,
        darks=g.darks.describe(),
        dark_matches=g.dark_matches(),
        pixel_scale_source=g.pixel_scale_source,
        last_error=g.last_error,
        mount=MountReport(dec=m.dec, pier_side=m.pier_side, slewing=m.slewing) if m else None,
        preferred_star=g.preferred_star,
        prediction=g.prediction(),
    )


@router.get("/view", response_model=ViewInfo)
async def get_view(request: Request) -> ViewInfo:
    """The guide camera's latest frame, described: its size and the stars to draw on it."""
    return _guider(request).view.info()


@router.get("/frame.jpg")
async def get_frame(request: Request, v: int | None = None) -> Response:
    """The latest frame as a stretched JPEG. *v* (the view's version) only busts caches."""
    data = _guider(request).view.jpeg()
    if data is None:
        raise HTTPException(status_code=404, detail="No frame yet")
    return Response(content=data, media_type="image/jpeg", headers={"Cache-Control": "no-store"})


@router.post("/preview", dependencies=[_ACTIVE], status_code=204, response_model=None)
async def start_preview(request: Request) -> None:
    """Show the guide camera (and the stars it would guide on) without guiding."""
    try:
        await _guider(request).start_preview()
    except GuiderError as exc:
        raise _conflict(exc) from exc


@router.delete("/preview", status_code=204, response_model=None)
async def stop_preview(request: Request) -> None:
    await _guider(request).stop_preview()


class StarPick(BaseModel):
    x: float  # sensor pixels
    y: float


@router.post("/star", dependencies=[_ACTIVE], status_code=204, response_model=None)
async def select_star(body: StarPick, request: Request) -> None:
    """Guide on the star nearest to (x, y) in the preview."""
    g = _guider(request)
    if g.status().active:
        raise _conflict(GuiderError("Stop guiding to choose another star"))
    if g.select_star(body.x, body.y) is None:
        raise HTTPException(status_code=404, detail="No star there")


@router.delete("/star", status_code=204, response_model=None)
async def clear_star(request: Request) -> None:
    """Let the guider choose the guide star again."""
    _guider(request).preferred_star = None


class GuideBody(BaseModel):
    settle: SettleParams = SettleParams()
    recalibrate: bool = False


@router.post("/guide", dependencies=[_ACTIVE], status_code=204, response_model=None)
async def guide(request: Request, body: GuideBody | None = None) -> None:
    """Start guiding. Returns at once; progress arrives as guiding events."""
    body = body or GuideBody()
    g = _guider(request)
    try:
        await g.guide(body.settle, recalibrate=body.recalibrate, wait_settle=False)
    except GuiderError as exc:
        raise _conflict(exc) from exc


@router.post("/stop", status_code=204, response_model=None)
async def stop(request: Request) -> None:
    await _guider(request).stop()


@router.post("/pause", dependencies=[_ACTIVE], status_code=204, response_model=None)
async def pause(request: Request) -> None:
    await _guider(request).pause()


@router.post("/resume", dependencies=[_ACTIVE], status_code=204, response_model=None)
async def resume(request: Request) -> None:
    await _guider(request).resume()


class DitherBody(BaseModel):
    pixels: float = Field(default=3.0, gt=0)
    ra_only: bool = False
    settle: SettleParams = SettleParams()


@router.post("/dither", dependencies=[_ACTIVE], status_code=204, response_model=None)
async def dither(body: DitherBody, request: Request) -> None:
    """Dither and wait for the guider to settle."""
    try:
        await _guider(request).dither(body.pixels, body.ra_only, body.settle)
    except GuiderError as exc:
        raise _conflict(exc) from exc


@router.delete("/calibration", status_code=204, response_model=None)
async def clear_calibration(request: Request) -> None:
    """Forget the calibration: the next run calibrates again."""
    _guider(request).clear_calibration()


class DarkBody(BaseModel):
    count: int = Field(default=10, ge=1, le=50)
    # Besides the current exposure and gain: every combination of these as well.
    exposures: list[float] = Field(default=[], max_length=6)
    gains: list[int] = Field(default=[], max_length=6)

    @field_validator("exposures")
    @classmethod
    def _positive(cls, values: list[float]) -> list[float]:
        if any(v <= 0 for v in values):
            raise ValueError("exposures must be above 0 s")
        return values

    @field_validator("gains")
    @classmethod
    def _not_negative(cls, values: list[int]) -> list[int]:
        if any(v < 0 for v in values):
            raise ValueError("gains must not be negative")
        return values


@router.post("/darks", dependencies=[_ACTIVE], response_model=list[DarkInfo])
async def capture_dark(body: DarkBody, request: Request) -> list[DarkInfo]:
    """Take darks with the scope covered: one for the current exposure and gain, and one for
    each of the other exposures and gains asked for. Returns when the frames are in."""
    g = _guider(request)
    try:
        taken = await g.capture_darks(body.count, body.exposures, body.gains)
    except GuiderError as exc:
        raise _conflict(exc) from exc
    return [
        info for info in g.darks.describe()
        if any(info.region == d.region and (info.exposure, info.gain, info.binning) == d.settings for d in taken)
    ]


@router.delete("/darks", status_code=204, response_model=None)
async def clear_darks(request: Request) -> None:
    _guider(request).darks.clear()


@router.get("/settings", response_model=GuiderSettings)
async def get_settings(request: Request) -> GuiderSettings:
    return _guider(request).settings


@router.put("/settings", response_model=GuiderSettings)
async def put_settings(body: GuiderSettings, request: Request) -> GuiderSettings:
    """Exposure and gain apply at once, even while guiding; the rest at the next run."""
    g = _guider(request)
    try:
        await g.update_settings(body)
    except GuiderError as exc:
        raise _conflict(exc) from exc
    store = getattr(request.app.state, "profile_store", None)
    if store is not None:
        current = store.get_user_settings()
        updated = {**current.plugin_settings, "guider": body.model_dump()}
        store.update_user_settings(current.model_copy(update={"plugin_settings": updated}))
    logger.info("guider.settings_updated")
    return body
