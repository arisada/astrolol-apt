"""FastAPI router for the system management plugin."""
from __future__ import annotations

import asyncio
import os
import sys

import structlog
from fastapi import APIRouter, HTTPException, Request

from astrolol.plugins.system import development as _dev
from astrolol.plugins.system import network as _net
from astrolol.plugins.system import privileges as _priv
from astrolol.plugins.system import system_info as _si
from astrolol.plugins.system import throttle as _throttle
from astrolol.plugins.system.models import (
    CommandResult,
    DevelopmentInfo,
    HostnameInfo,
    HotspotStartRequest,
    NetworkStatus,
    SavedWifiConnection,
    SetHostnameRequest,
    StorageDisk,
    PermissionSetup,
    SystemSettings,
    SystemStatus,
    ThrottleStatus,
    TimeInfo,
    UsbDevice,
    WifiConnectRequest,
    WifiNetwork,
)
from astrolol.version import SERVER_VERSION

logger = structlog.get_logger()

router = APIRouter(prefix="/plugins/system", tags=["system"])

_PLUGIN_KEY = "system"


def _settings(request: Request) -> SystemSettings:
    raw = request.app.state.profile_store.get_user_settings().plugin_settings.get(_PLUGIN_KEY, {})
    return SystemSettings(**raw)


def _save_settings(request: Request, s: SystemSettings) -> None:
    store = request.app.state.profile_store
    current = store.get_user_settings()
    updated = {**current.plugin_settings, _PLUGIN_KEY: s.model_dump()}
    store.update_user_settings(current.model_copy(update={"plugin_settings": updated}))


# ── System status ──────────────────────────────────────────────────────────────

@router.get("/status", response_model=SystemStatus)
async def get_system_status() -> SystemStatus:
    """Return CPU, memory, disk, temperature, and uptime."""
    return await _si.get_system_status()


@router.get("/throttled", response_model=ThrottleStatus)
async def get_throttled_status() -> ThrottleStatus:
    """Return current power/thermal throttling status (vcgencmd get_throttled or sysfs)."""
    return await _throttle.get_throttle_status()


# ── Network ────────────────────────────────────────────────────────────────────

@router.get("/network", response_model=NetworkStatus)
async def get_network_status() -> NetworkStatus:
    """Return current network mode, SSID, and IP addresses."""
    return await _net.get_network_status()


@router.get("/network/scan", response_model=list[WifiNetwork])
async def scan_wifi(request: Request) -> list[WifiNetwork]:
    """Scan for available WiFi networks. May take a couple of seconds."""
    s = _settings(request)
    return await _net.scan_wifi(interface=s.hotspot_interface or None)


@router.post("/network/connect", status_code=200)
async def connect_wifi(body: WifiConnectRequest, request: Request) -> dict[str, str]:
    """Connect to a WiFi network."""
    s = _settings(request)
    try:
        await _net.connect_wifi(
            ssid=body.ssid,
            password=body.password,
            interface=body.interface or s.hotspot_interface or None,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return {"status": "connected", "ssid": body.ssid}


@router.get("/network/saved", response_model=list[SavedWifiConnection])
async def list_saved_connections() -> list[SavedWifiConnection]:
    """Return saved WiFi connection profiles."""
    return await _net.list_saved_wifi_connections()


@router.delete("/network/saved/{name}", status_code=204, response_model=None)
async def delete_saved_connection(name: str) -> None:
    """Delete a saved WiFi connection profile by name."""
    try:
        await _net.delete_saved_connection(name)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/network/disconnect", status_code=200)
async def disconnect_wifi(request: Request) -> dict[str, str]:
    """Disconnect from the current WiFi network."""
    s = _settings(request)
    try:
        await _net.disconnect_wifi(interface=s.hotspot_interface or None)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return {"status": "disconnected"}


@router.post("/network/hotspot/start", status_code=200)
async def start_hotspot(body: HotspotStartRequest, request: Request) -> dict[str, str]:
    """Start a WiFi access point (hotspot/AP mode)."""
    s = _settings(request)
    ssid = body.ssid or s.hotspot_ssid
    password = body.password or s.hotspot_password
    interface = body.interface or s.hotspot_interface or None

    if len(password) < 8:
        raise HTTPException(status_code=400, detail="Hotspot password must be at least 8 characters")

    try:
        await _net.start_hotspot(ssid=ssid, password=password, interface=interface)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {"status": "hotspot_active", "ssid": ssid}


@router.post("/network/hotspot/stop", status_code=200)
async def stop_hotspot(request: Request) -> dict[str, str]:
    """Stop the WiFi hotspot and return to station mode."""
    try:
        await _net.stop_hotspot()
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    watchdog = getattr(request.app.state, "system_network_watchdog", None)
    if watchdog is not None:
        watchdog.suppress()
    return {"status": "hotspot_stopped"}


# ── Settings ───────────────────────────────────────────────────────────────────

@router.get("/settings", response_model=SystemSettings)
async def get_settings(request: Request) -> SystemSettings:
    return _settings(request)


@router.put("/settings", response_model=SystemSettings)
async def put_settings(body: SystemSettings, request: Request) -> SystemSettings:
    _save_settings(request, body)
    monitor = getattr(request.app.state, "system_throttle_monitor", None)
    if monitor is not None:
        await monitor.apply_settings(
            enabled=body.throttle_monitor_enabled,
            interval_seconds=body.throttle_check_interval_seconds,
        )
    return body


# ── Permissions (polkit) ───────────────────────────────────────────────────────

@router.get("/permissions", response_model=PermissionSetup)
async def get_permissions() -> PermissionSetup:
    """Which host-management actions polkit allows astrolol, and how to allow the others."""
    ok = await _priv.check()
    return PermissionSetup(
        network_ok=ok["network"],
        reboot_ok=ok["reboot"],
        shutdown_ok=ok["shutdown"],
        hostname_ok=ok["hostname"],
        timezone_ok=ok["timezone"],
        setup_commands=[] if all(ok.values()) else _priv.setup_commands(),
    )


# ── USB devices ───────────────────────────────────────────────────────────────

@router.get("/usb", response_model=list[UsbDevice])
async def get_usb_devices() -> list[UsbDevice]:
    """Return connected non-hub USB devices."""
    return await _si.get_usb_devices()


# ── Storage ───────────────────────────────────────────────────────────────────

@router.get("/storage", response_model=list[StorageDisk])
async def get_storage() -> list[StorageDisk]:
    """Return mounted filesystems with usage statistics."""
    return await _si.get_storage_disks()


# ── Time / Timezone ────────────────────────────────────────────────────────────

@router.get("/time", response_model=TimeInfo)
async def get_time_info() -> TimeInfo:
    """Return current time, timezone, and NTP sync status."""
    return await _si.get_time_info()


@router.get("/time/timezones", response_model=list[str])
async def list_timezones() -> list[str]:
    """Return all available timezone names."""
    return await _si.get_available_timezones()


@router.put("/time/timezone", status_code=200)
async def set_timezone(body: dict, request: Request) -> dict[str, str]:
    """Set the system timezone (timedatectl; allowed by the polkit rule)."""
    tz = body.get("timezone", "").strip()
    if not tz:
        raise HTTPException(status_code=400, detail="timezone is required")
    try:
        await _si.set_timezone(tz)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return {"timezone": tz}


# ── Hostname ───────────────────────────────────────────────────────────────────

@router.get("/hostname", response_model=HostnameInfo)
async def get_hostname() -> HostnameInfo:
    """Return current hostname and FQDN."""
    return await _si.get_hostname_info()


@router.put("/hostname", status_code=200, response_model=HostnameInfo)
async def set_hostname(body: SetHostnameRequest) -> HostnameInfo:
    """Change the system hostname (hostnamectl; allowed by the polkit rule)."""
    import re
    if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$', body.hostname):
        raise HTTPException(
            status_code=400,
            detail="Hostname must consist of alphanumeric characters and hyphens, not starting/ending with a hyphen",
        )
    try:
        await _si.set_hostname(body.hostname)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return await _si.get_hostname_info()


# ── Power controls ─────────────────────────────────────────────────────────────

@router.post("/reboot", status_code=202)
async def reboot_system() -> dict[str, str]:
    """Reboot the host system (systemd; allowed by the polkit rule)."""
    async def _do() -> None:
        await asyncio.sleep(0.5)
        logger.info("system.rebooting")
        proc = await asyncio.create_subprocess_exec("systemctl", "reboot")
        await proc.wait()

    asyncio.create_task(_do())
    return {"status": "rebooting"}


@router.post("/shutdown", status_code=202)
async def shutdown_system() -> dict[str, str]:
    """Power off the host system (systemd; allowed by the polkit rule)."""
    async def _do() -> None:
        await asyncio.sleep(0.5)
        logger.info("system.shutting_down")
        proc = await asyncio.create_subprocess_exec("systemctl", "poweroff")
        await proc.wait()

    asyncio.create_task(_do())
    return {"status": "shutting_down"}


@router.post("/restart", status_code=202)
async def restart_astrolol() -> dict[str, str]:
    """Restart the astrolol process (same as /admin/restart)."""
    async def _do() -> None:
        await asyncio.sleep(0.3)
        logger.info("system.restarting_astrolol")
        os.execv(sys.executable, [sys.executable] + sys.argv)

    asyncio.create_task(_do())
    return {"status": "restarting"}


# ── Development ────────────────────────────────────────────────────────────────

@router.get("/dev", response_model=DevelopmentInfo)
async def dev_info() -> DevelopmentInfo:
    """The installed version, and whether this install can update itself from git."""
    return DevelopmentInfo(checkout=_dev.is_checkout(), version=SERVER_VERSION)


async def _exclusive_dev(request: Request, command):  # noqa: ANN001, ANN202
    """Run one development command at a time (a second click while one runs is refused)."""
    if not _dev.is_checkout():
        # A packaged install: updates come with the system's package updates.
        raise HTTPException(status_code=409, detail="astrolol is not running from a git checkout")
    lock: asyncio.Lock | None = getattr(request.app.state, "system_dev_lock", None)
    if lock is None:
        lock = request.app.state.system_dev_lock = asyncio.Lock()
    if lock.locked():
        raise HTTPException(status_code=409, detail="A development command is already running")
    async with lock:
        return await command()


@router.post("/dev/git_pull", response_model=CommandResult)
async def dev_git_pull(request: Request) -> CommandResult:
    """git pull --ff-only in the astrolol checkout."""
    return await _exclusive_dev(request, _dev.git_pull)


@router.post("/dev/rebuild_ui", response_model=CommandResult)
async def dev_rebuild_ui(request: Request) -> CommandResult:
    """npm run build in the ui directory."""
    return await _exclusive_dev(request, _dev.rebuild_ui)
