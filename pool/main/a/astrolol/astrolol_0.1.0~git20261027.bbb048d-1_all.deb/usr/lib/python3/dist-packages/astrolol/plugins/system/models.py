"""Pydantic models for the system management plugin."""
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class CommandResult(BaseModel):
    ok: bool
    output: str


class DevelopmentInfo(BaseModel):
    checkout: bool   # running from a git checkout: git pull and the UI rebuild are available
    version: str


class NetworkMode(str, Enum):
    wifi = "wifi"
    hotspot = "hotspot"
    disconnected = "disconnected"
    unknown = "unknown"


class WifiNetwork(BaseModel):
    ssid: str
    bssid: str
    signal: int  # 0–100
    security: str
    in_use: bool = False


class NetworkStatus(BaseModel):
    mode: NetworkMode
    interface: str | None
    ssid: str | None
    ip_address: str | None
    gateway: str | None
    hotspot_ssid: str | None
    hotspot_ip: str | None
    nmcli_available: bool


class SystemStatus(BaseModel):
    cpu_percent: float
    memory_percent: float
    memory_used_mb: float
    memory_total_mb: float
    disk_percent: float
    disk_used_gb: float
    disk_total_gb: float
    temperature_celsius: float | None
    uptime_seconds: float
    hostname: str
    platform: str


class WifiConnectRequest(BaseModel):
    ssid: str
    password: str
    interface: str | None = None


class HotspotStartRequest(BaseModel):
    ssid: str | None = None
    password: str | None = None
    interface: str | None = None


class NetworkPolicy(str, Enum):
    auto = "auto"          # known Wi-Fi when in range, hotspot otherwise
    wifi = "wifi"          # never start the hotspot by itself
    hotspot = "hotspot"    # always the hotspot (after the boot window)


class SystemSettings(BaseModel):
    hotspot_ssid: str = Field(default="AstroLOL")
    hotspot_password: str = Field(default="astronomy123")
    hotspot_interface: str = Field(default="wlan0")
    network_policy: NetworkPolicy = Field(default=NetworkPolicy.auto)
    # After a boot the hotspot is held back this long so a known Wi-Fi network (home) always
    # gets a chance to connect: a way in if the hotspot ever misbehaves.
    boot_wifi_window_seconds: int = Field(default=60, ge=0, le=600)
    # Wi-Fi lost while running: wait this long before falling back to the hotspot.
    lost_wifi_grace_seconds: int = Field(default=120, ge=0, le=3600)
    throttle_monitor_enabled: bool = Field(default=True)
    # Under-voltage dips are typically brief (a few seconds), so this defaults
    # low — a sysfs read is cheap (no subprocess spawn) and safe to do often.
    throttle_check_interval_seconds: int = Field(default=1, ge=1, le=3600)


class PermissionSetup(BaseModel):
    """Which host-management actions polkit allows astrolol (see privileges.py)."""
    network_ok: bool
    reboot_ok: bool
    shutdown_ok: bool
    hostname_ok: bool
    timezone_ok: bool
    setup_commands: list[str]   # to run as root when some are missing (installs from source)


class TimeInfo(BaseModel):
    datetime_local: str        # ISO 8601 local time
    datetime_utc: str          # ISO 8601 UTC
    timezone: str              # e.g. "Europe/Brussels"
    ntp_synced: bool
    ntp_service_active: bool
    rtc_time: str | None


class StorageDisk(BaseModel):
    device: str
    mountpoint: str
    filesystem: str
    total_gb: float
    used_gb: float
    free_gb: float
    percent: float
    removable: bool


class HostnameInfo(BaseModel):
    hostname: str
    fqdn: str | None


class SetHostnameRequest(BaseModel):
    hostname: str = Field(min_length=1, max_length=63)


class UsbDevice(BaseModel):
    bus: str
    device: str
    vendor_id: str
    product_id: str
    name: str


class SavedWifiConnection(BaseModel):
    name: str
    interface: str | None
    autoconnect: bool


class ThrottleStatus(BaseModel):
    available: bool             # False when neither vcgencmd nor the sysfs file could be read
    source: str                 # "vcgencmd" | "sysfs" | "unavailable"
    raw_hex: str | None         # raw bitmask, e.g. "0x50005"
    under_voltage: bool
    freq_capped: bool
    throttled: bool
    soft_temp_limit: bool
    under_voltage_occurred: bool
    freq_capped_occurred: bool
    throttled_occurred: bool
    soft_temp_limit_occurred: bool
    underpowered: bool          # True if any of the four "now" flags above is set
