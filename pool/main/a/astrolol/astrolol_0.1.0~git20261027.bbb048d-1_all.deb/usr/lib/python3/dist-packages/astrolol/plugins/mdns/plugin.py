"""mDNS plugin for astrolol — advertises the server on the local network so the Android
app (or anything else) can find it via _astrolol._tcp.local. instead of a typed-in IP.
"""
from __future__ import annotations

import structlog
from fastapi import FastAPI

from astrolol.core.auth import AclRule, Level
from astrolol.core.plugin_api import PluginContext, PluginManifest
from astrolol.plugins.mdns.models import MdnsSettings
from astrolol.plugins.mdns.service import MdnsAdvertiser

logger = structlog.get_logger()


class MdnsPlugin:
    manifest = PluginManifest(
        id="mdns",
        nav_group="settings",
        name="mDNS Discovery",
        version="0.1.0",
        description="Advertises this astrolol server on the local network via mDNS.",
        nav_order=95,
        acl_rules=[
            AclRule("/plugins/mdns/settings", Level.ADMIN, ("PUT",)),
        ],
    )

    def __init__(self) -> None:
        self._advertiser = MdnsAdvertiser()
        self._ctx: PluginContext | None = None

    def setup(self, app: FastAPI, ctx: PluginContext) -> None:
        from astrolol.plugins.mdns.api import router
        app.include_router(router)
        self._ctx = ctx
        logger.info("mdns.plugin_setup")

    async def startup(self) -> None:
        assert self._ctx is not None
        settings = self._ctx.get_plugin_settings("mdns", MdnsSettings)
        await self._advertiser.start(settings)

    async def shutdown(self) -> None:
        await self._advertiser.stop()


def get_plugin() -> MdnsPlugin:
    return MdnsPlugin()
