from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

from astrolol.core.errors import DeviceNotFoundError, DeviceKindError
from astrolol.devices.base.models import CameraStatus
from astrolol.imaging.imager import ImagerManager
from astrolol.core.events import ImageStats
from astrolol.imaging.models import ExposureRequest, ExposureResult, ImagerDeviceSettings, ImagerStatus
from astrolol.profiles.store import ProfileStore

router = APIRouter(prefix="/imager", tags=["imager"])


def _imager(request: Request) -> ImagerManager:
    return request.app.state.imager_manager


@router.get("/status", response_model=list[ImagerStatus])
async def all_statuses(request: Request) -> list[ImagerStatus]:
    """Status of all known camera imagers."""
    return _imager(request).all_statuses()


@router.get("/{device_id}/status", response_model=ImagerStatus)
async def status(device_id: str, request: Request) -> ImagerStatus:
    return _imager(request).get_status(device_id)


@router.post("/{device_id}/expose", response_model=ExposureResult, status_code=201)
async def expose(device_id: str, body: ExposureRequest, request: Request) -> ExposureResult:
    """Take a single exposure. Blocks until the exposure is complete."""
    try:
        return await _imager(request).expose(device_id, body)
    except (DeviceNotFoundError, DeviceKindError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/{device_id}/loop", status_code=202)
async def start_loop(device_id: str, body: ExposureRequest, request: Request) -> dict[str, str]:
    """Start a looping exposure sequence. Returns immediately; subscribe to /ws/events for results."""
    try:
        await _imager(request).start_loop(device_id, body)
        return {"status": "looping", "device_id": device_id}
    except (DeviceNotFoundError, DeviceKindError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.delete("/{device_id}/loop", status_code=204, response_model=None)
async def stop_loop(device_id: str, request: Request) -> None:
    """Stop a running loop after the current exposure completes."""
    try:
        await _imager(request).stop_loop(device_id)
    except (DeviceNotFoundError, DeviceKindError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/{device_id}/halt", status_code=204, response_model=None)
async def halt(device_id: str, request: Request) -> None:
    """Immediately abort any running exposure and cancel any active loop."""
    try:
        await _imager(request).halt(device_id)
    except (DeviceNotFoundError, DeviceKindError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/{device_id}/camera_status", response_model=CameraStatus)
async def camera_status(device_id: str, request: Request) -> CameraStatus:
    """Current camera hardware status: temperature, cooler, etc."""
    try:
        camera = _imager(request)._device_manager.get_camera(device_id)
        return await camera.get_status()
    except (DeviceNotFoundError, DeviceKindError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))


class SetCoolerRequest(BaseModel):
    enabled: bool
    target_temperature: float | None = None


@router.post("/{device_id}/cooler", status_code=204, response_model=None)
async def set_cooler(device_id: str, body: SetCoolerRequest, request: Request) -> None:
    """Enable/disable the camera cooler and optionally set a target temperature."""
    try:
        camera = _imager(request)._device_manager.get_camera(device_id)
        await camera.set_cooler(body.enabled, body.target_temperature)
    except (DeviceNotFoundError, DeviceKindError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/{device_id}/stats", response_model=ImageStats)
async def get_stats(device_id: str, request: Request) -> ImageStats:
    """Return statistics from the most recent exposure for this camera."""
    stats = _imager(request).get_last_stats(device_id)
    if stats is None:
        raise HTTPException(status_code=404, detail="No statistics available yet")
    return stats


@router.get("/{device_id}/preview.jpg")
async def render_preview(
    device_id: str, request: Request,
    mode: str = "auto",
    target_bg: float = Query(0.25, gt=0.0, lt=1.0),
    shadows: float = Query(-2.8, ge=-10.0, le=0.0),
    quality: int = Query(85, ge=1, le=100),
    color: bool = True,
    linked: bool = False,
) -> FileResponse:
    """On-demand re-stretch of the *last* exposure for this camera — lets the Imaging
    page reflect a JPEG-quality/background/shadows change immediately, without
    waiting for (or forcing) a new exposure. Independent of the auto-generated
    preview_path/preview_path_linear files a completed exposure already carries;
    those keep using the camera's persisted settings for the *next* exposure."""
    import asyncio
    import tempfile

    from astrolol.core.mem_guard import mem_guard
    from astrolol.imaging.preview import render_auto, render_linear

    imager = _imager(request)
    fits_path = imager.get_last_fits_path(device_id)
    if fits_path is None or not Path(fits_path).exists():
        raise HTTPException(status_code=404, detail="No exposure available yet.")

    tmp_dir = Path(tempfile.gettempdir()) / "astrolol"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    out_path = tmp_dir / f"live_preview_{device_id}.jpg"

    def _render() -> None:
        # Normally a cache hit — the exposure already built this frame's base.
        base = imager.preview_cache.load(Path(fits_path))
        if mode == "linear":
            render_linear(base, out_path, quality, color=color)
        else:
            render_auto(base, out_path, quality, target_bg, shadows, color=color, linked=linked)

    async with mem_guard():
        await asyncio.to_thread(_render)
    return FileResponse(out_path, media_type="image/jpeg")


@router.get("/{device_id}/settings", response_model=ImagerDeviceSettings)
async def get_device_settings(device_id: str, request: Request) -> ImagerDeviceSettings:
    """Return persisted imager settings for a specific camera (defaults if not yet saved)."""
    store: ProfileStore = request.app.state.profile_store
    raw = store.get_user_settings().imager_settings.get(device_id, {})
    return ImagerDeviceSettings(**raw)


@router.put("/{device_id}/settings", response_model=ImagerDeviceSettings)
async def put_device_settings(device_id: str, body: ImagerDeviceSettings, request: Request) -> ImagerDeviceSettings:
    """Persist imager settings for a specific camera."""
    store: ProfileStore = request.app.state.profile_store
    current = store.get_user_settings()
    new_map = {**current.imager_settings, device_id: body.model_dump()}
    store.update_user_settings(current.model_copy(update={"imager_settings": new_map}))
    return body


@router.get("/images/{filename}")
async def serve_image(filename: str) -> FileResponse:
    """Serve a JPEG preview by filename (basename only — no subdirectory traversal)."""
    from astrolol.config.settings import settings

    # Reject any path separators in the filename before touching the filesystem
    if "/" in filename or "\\" in filename or filename.startswith("."):
        raise HTTPException(status_code=400, detail="Invalid filename.")

    images_root = settings.images_dir.resolve()
    path = (images_root / filename).resolve()

    # Verify the resolved path is still inside images_dir
    try:
        path.relative_to(images_root)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid filename.")

    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail=f"Image '{filename}' not found.")

    media_type = "image/jpeg" if path.suffix.lower() in (".jpg", ".jpeg") else "application/octet-stream"
    return FileResponse(path, media_type=media_type)
