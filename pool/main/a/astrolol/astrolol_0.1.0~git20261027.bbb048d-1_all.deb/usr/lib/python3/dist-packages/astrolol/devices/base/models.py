from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class DeviceState(StrEnum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    BUSY = "busy"
    ERROR = "error"


class TrackingMode(StrEnum):
    SIDEREAL = "sidereal"
    LUNAR = "lunar"
    SOLAR = "solar"


# --- Camera ---

class ExposureParams(BaseModel):
    duration: float = Field(gt=0, description="Exposure duration in seconds")
    gain: int | None = Field(default=None, ge=0, description="None = leave driver gain unchanged")
    binning: int = Field(default=1, ge=1, le=4)
    frame_type: str = Field(default="light", description="light | dark | flat | bias")


class Image(BaseModel):
    fits_path: str
    width: int
    height: int
    exposure_duration: float


class CameraStatus(BaseModel):
    state: DeviceState
    temperature: float | None = None
    cooler_on: bool = False
    cooler_power: float | None = None


# --- Mount ---

class Target(BaseModel):
    """A sky position of interest, stored in ICRS (J2000)."""
    ra: float            # ICRS degrees
    dec: float           # ICRS degrees
    name: str | None = None
    source: str | None = None   # who set it: "user" | "catalogue" | "stellarium" | …
    set_at: datetime

    @property
    def skycoord(self) -> "SkyCoord":
        from astropy.coordinates import SkyCoord
        import astropy.units as u
        return SkyCoord(ra=self.ra * u.deg, dec=self.dec * u.deg, frame="icrs")


class MountStatus(BaseModel):
    state: DeviceState
    ra: float | None = None        # ICRS (J2000) decimal hours
    dec: float | None = None       # ICRS (J2000) decimal degrees
    ra_jnow: float | None = None   # JNow decimal hours (FK5 current epoch)
    dec_jnow: float | None = None  # JNow decimal degrees (FK5 current epoch)
    alt: float | None = None
    az: float | None = None
    is_tracking: bool = False
    is_parked: bool = False
    is_slewing: bool = False
    is_synced: bool | None = None   # None = adapter doesn't track this (e.g. INDI's own alignment
                                     # model always has *a* position); False = raw position only,
                                     # ra/dec below should not be trusted for pointing decisions.
    pier_side: str | None = None    # "East" | "West" — which side of the pier the OTA is on
    hour_angle: float | None = None   # decimal hours, negative = east (pre-meridian), positive = west (post)
    lst: float | None = None           # Local Sidereal Time in decimal hours

    @property
    def skycoord(self) -> "SkyCoord | None":
        """Return current position as an ICRS SkyCoord, or None if unknown."""
        if self.ra is None or self.dec is None:
            return None
        from astropy.coordinates import SkyCoord
        import astropy.units as u
        return SkyCoord(ra=self.ra * u.hourangle, dec=self.dec * u.deg, frame="icrs")


# --- Focuser ---

class FocuserStatus(BaseModel):
    state: DeviceState
    position: int | None = None
    is_moving: bool = False
    temperature: float | None = None


# --- Filter Wheel ---

class FilterWheelStatus(BaseModel):
    state: DeviceState
    current_slot: int | None = None   # 1-indexed
    filter_count: int | None = None
    filter_names: list[str] = []
    is_moving: bool = False


# --- Flat panel / dust cover ---

class CoverState(StrEnum):
    OPEN = "open"
    CLOSED = "closed"
    MOVING = "moving"
    UNKNOWN = "unknown"


class FlatPanelStatus(BaseModel):
    state: DeviceState
    has_cover: bool = False          # motorised dust cover (cap)
    cover: CoverState | None = None  # None when the device has no cover
    has_light: bool = False
    light_on: bool | None = None
    brightness: int | None = None
    max_brightness: int | None = None


# --- Rotator ---

class RotatorStatus(BaseModel):
    state: DeviceState
    position: float | None = None    # degrees
    is_moving: bool = False
