from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4

from pydantic import BaseModel, Field

from astrolol.devices.base.models import DeviceState


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _uid() -> str:
    return str(uuid4())


class ChannelStats(BaseModel):
    """Per-colour-channel statistics of a debayered (one-shot-colour) frame."""
    name: Literal["R", "G", "B"]
    histogram: list[int]    # full-resolution counts, same bins as ImageStats.histogram
    median: float           # full-resolution background (ADU)
    noise_sigma: float
    display_median: float   # binned preview the stretch is computed on
    display_sigma: float
    stretch_low: float      # this channel's auto-stretch (shared ones when linked)
    stretch_high: float
    stretch_midtone: float


class ImageStats(BaseModel):
    """Statistics computed from the last exposure (histogram + optional star analysis)."""
    histogram: list[int]    # 128-bin full-resolution ADU distribution over [hist_min, hist_max]
    hist_min: float         # 0
    hist_max: float         # sensor full-scale ADU (the frame's own max for float FITS)
    stretch_low: float      # auto-stretch black point (ADU)
    stretch_high: float     # auto-stretch white point (ADU) — full scale, no highlight clip
    stretch_midtone: float = 0.5  # auto-stretch midtones balance (0.5 = linear)
    mean: float
    median: float           # full-resolution sky background (ADU)
    noise_sigma: float = 0.0              # full-resolution background noise, 1.4826·MAD (ADU)
    saturated_pct: float | None = None    # % of pixels at full scale; None without a fixed full scale
    # Statistics of the binned preview the stretch is computed on — lets a client
    # redraw the stretch curve for other parameters without asking the server.
    display_median: float = 0.0
    display_sigma: float = 0.0
    channels: list[ChannelStats] | None = None  # colour frames only; scalars above are luminance
    fwhm: float | None = None   # median FWHM in pixels; None when autofocus plugin is not loaded
    star_count: int = 0


NotifySeverity = Literal["info", "warning", "critical"]


class BaseEvent(BaseModel):
    id: str = Field(default_factory=_uid)
    timestamp: datetime = Field(default_factory=_now)

    # Set only by unattended code paths (automation loops, the sequencer runner,
    # watchdogs) that publish an event with nobody already looking at a response —
    # never by request-handler code, since the same event class can also fire
    # synchronously in reaction to a user action (which belongs in the error log
    # only). None means "not notify-worthy"; clients ignore it either way.
    notify: NotifySeverity | None = None
    notify_title: str | None = None
    notify_body: str | None = None


# --- Device events ---

class DeviceConnected(BaseEvent):
    type: Literal["device.connected"] = "device.connected"
    device_kind: str
    device_key: str


class DeviceDisconnected(BaseEvent):
    type: Literal["device.disconnected"] = "device.disconnected"
    device_kind: str
    device_key: str
    reason: str | None = None


class DeviceStateChanged(BaseEvent):
    type: Literal["device.state_changed"] = "device.state_changed"
    device_kind: str
    device_key: str
    old_state: DeviceState
    new_state: DeviceState


# --- Log event (for live log streaming to clients) ---

class LogEvent(BaseEvent):
    type: Literal["log"] = "log"
    level: str  # "debug" | "info" | "warning" | "error"
    component: str
    message: str


# --- Imager events ---

class ExposureStarted(BaseEvent):
    type: Literal["imager.exposure_started"] = "imager.exposure_started"
    device_id: str
    duration: float
    gain: int | None
    binning: int


class ExposureCompleted(BaseEvent):
    type: Literal["imager.exposure_completed"] = "imager.exposure_completed"
    device_id: str
    fits_path: str
    preview_path: str
    preview_path_linear: str | None = None
    duration: float
    width: int
    height: int
    stats: ImageStats | None = None


class ExposureFailed(BaseEvent):
    type: Literal["imager.exposure_failed"] = "imager.exposure_failed"
    device_id: str
    reason: str


class LoopStarted(BaseEvent):
    type: Literal["imager.loop_started"] = "imager.loop_started"
    device_id: str


class LoopStopped(BaseEvent):
    type: Literal["imager.loop_stopped"] = "imager.loop_stopped"
    device_id: str


# --- Mount events ---

class MountSlewStarted(BaseEvent):
    type: Literal["mount.slew_started"] = "mount.slew_started"
    device_id: str
    ra: float   # ICRS degrees
    dec: float  # ICRS degrees


class MountSlewCompleted(BaseEvent):
    type: Literal["mount.slew_completed"] = "mount.slew_completed"
    device_id: str
    ra: float   # ICRS degrees
    dec: float  # ICRS degrees


class MountSlewAborted(BaseEvent):
    type: Literal["mount.slew_aborted"] = "mount.slew_aborted"
    device_id: str


class MountTargetSet(BaseEvent):
    type: Literal["mount.target_set"] = "mount.target_set"
    device_id: str
    ra: float            # ICRS degrees
    dec: float           # ICRS degrees
    name: str | None = None
    source: str | None = None


class MountParked(BaseEvent):
    type: Literal["mount.parked"] = "mount.parked"
    device_id: str


class MountSynced(BaseEvent):
    type: Literal["mount.synced"] = "mount.synced"
    device_id: str
    ra: float   # ICRS degrees
    dec: float  # ICRS degrees


class MountTrackingChanged(BaseEvent):
    type: Literal["mount.tracking_changed"] = "mount.tracking_changed"
    device_id: str
    tracking: bool
    mode: str | None = None


class MountUnparked(BaseEvent):
    type: Literal["mount.unparked"] = "mount.unparked"
    device_id: str


class MountOperationFailed(BaseEvent):
    type: Literal["mount.operation_failed"] = "mount.operation_failed"
    device_id: str
    operation: str  # "slew" | "park" | "meridian_flip"
    reason: str


class MountMeridianFlipStarted(BaseEvent):
    type: Literal["mount.meridian_flip_started"] = "mount.meridian_flip_started"
    device_id: str


class MountMeridianFlipCompleted(BaseEvent):
    type: Literal["mount.meridian_flip_completed"] = "mount.meridian_flip_completed"
    device_id: str


# --- Focuser events ---

class FocuserMoveStarted(BaseEvent):
    type: Literal["focuser.move_started"] = "focuser.move_started"
    device_id: str
    target_position: int


class FocuserMoveCompleted(BaseEvent):
    type: Literal["focuser.move_completed"] = "focuser.move_completed"
    device_id: str
    position: int


class FocuserHalted(BaseEvent):
    type: Literal["focuser.halted"] = "focuser.halted"
    device_id: str
    position: int | None = None


class FocuserPositionUpdated(BaseEvent):
    """High-frequency event: fired on every ABS_FOCUS_POSITION update from the driver.
    Not written to the event log — used only for real-time UI state updates."""
    type: Literal["focuser.position_updated"] = "focuser.position_updated"
    device_id: str
    position: int


class MountCoordsUpdated(BaseEvent):
    """High-frequency event: fired at most 1 Hz when EQUATORIAL_EOD_COORD changes.
    Not written to the event log — used for real-time RA/Dec in the UI and plugins
    (e.g. Stellarium sync).  Carries the full mount status so the UI can drive
    entirely from this event without a separate REST poll."""
    type: Literal["mount.coords_updated"] = "mount.coords_updated"
    device_id: str
    ra: float | None       # ICRS J2000 decimal hours
    dec: float | None      # ICRS J2000 decimal degrees
    ra_jnow: float | None  # JNow decimal hours (raw driver value)
    dec_jnow: float | None # JNow decimal degrees (raw driver value)
    alt: float | None = None
    az: float | None = None
    pier_side: str | None = None
    hour_angle: float | None = None
    lst: float | None = None
    is_tracking: bool = False
    is_parked: bool = False


# --- Flat panel events ---

class FlatPanelChanged(BaseEvent):
    type: Literal["flat_panel.changed"] = "flat_panel.changed"
    device_id: str
    cover: str | None = None
    light_on: bool | None = None
    brightness: int | None = None


# --- Filter Wheel events ---

class FilterWheelFilterChanged(BaseEvent):
    type: Literal["filter_wheel.filter_changed"] = "filter_wheel.filter_changed"
    device_id: str
    slot: int
    filter_name: str | None = None


