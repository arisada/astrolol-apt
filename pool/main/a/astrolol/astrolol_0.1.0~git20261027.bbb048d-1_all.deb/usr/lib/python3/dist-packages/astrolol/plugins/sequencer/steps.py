"""Step implementations: the hardware actions the runner performs.

A step either succeeds, is *unavailable* (the plugin or device it needs is absent → a
``step_skipped`` event, and the run continues), or *fails* (→ ``StepError``, handled by
the task's error policy). Nothing fails silently.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections.abc import Awaitable, Callable
from typing import Any, Protocol, cast

import structlog

from astrolol.core.events.models import BaseEvent
from astrolol.core.guiding import Guider, GuiderNotConnected, SettleParams
from astrolol.core.sequencer.events import (
    SequencerStepFailed,
    SequencerStepFinished,
    SequencerStepSkipped,
    SequencerStepStarted,
    StepDetails,
    StepKind,
)
from astrolol.core.sequencer.models import Activity, ExposureGroup, ImagingTask, StallKind
from astrolol.plugins.sequencer.devices import LaneDevices
from astrolol.plugins.sequencer.settings import SequencerSettings
from astrolol.plugins.sequencer.targets import ResolvedTarget, TargetUnresolvable, resolve_target

logger = structlog.get_logger()

# Steps after which a retry must re-run the task setup (slew → center → guide).
# Failures while exposing or changing filters are retried in place.
SETUP_STEPS: frozenset[str] = frozenset(
    {
        "resolve_target",
        "slew",
        "center",
        "stop_guiding",
        "start_guiding",
        "autofocus",
        "meridian_flip",
        "cooling",
    }
)


COOLING_POLL_S = 5.0


class StepError(Exception):
    """A step ran and failed. ``stall_kind`` is set for sky-dependent failures."""

    def __init__(self, step: StepKind, message: str, stall_kind: StallKind | None = None) -> None:
        super().__init__(message)
        self.step = step
        self.stall_kind = stall_kind

    @property
    def needs_setup(self) -> bool:
        return self.step in SETUP_STEPS


class StepHost(Protocol):
    """What steps need from the runner."""

    app: Any
    bus: Any

    @property
    def settings(self) -> SequencerSettings: ...

    async def set_activity(self, activity: Activity | None, message: str | None) -> None: ...


class Steps:
    def __init__(self, host: StepHost) -> None:
        self._host = host

    # ── Plumbing ───────────────────────────────────────────────────────────

    @property
    def _app(self) -> Any:
        return self._host.app

    def _state(self, name: str) -> Any:
        return getattr(self._app.state, name, None)

    async def _publish(self, event: BaseEvent) -> None:
        await self._host.bus.publish(event)

    async def _started(
        self, task_id: str | None, step: StepKind, activity: Activity | None, message: str
    ) -> float:
        await self._host.set_activity(activity, message)
        await self._publish(SequencerStepStarted(task_id=task_id, step=step, message=message))
        logger.info("sequencer.step_started", task_id=task_id, step=step, message=message)
        return time.monotonic()

    async def _finished(
        self, task_id: str | None, step: StepKind, t0: float, details: StepDetails | None = None
    ) -> None:
        duration = round(time.monotonic() - t0, 2)
        await self._publish(
            SequencerStepFinished(
                task_id=task_id, step=step, duration_s=duration, details=details or {}
            )
        )
        logger.info(
            "sequencer.step_finished",
            task_id=task_id,
            step=step,
            duration_s=duration,
            **(details or {}),
        )

    async def skipped(self, task_id: str | None, step: StepKind, reason: str) -> None:
        await self._publish(SequencerStepSkipped(task_id=task_id, step=step, reason=reason))
        logger.warning("sequencer.step_skipped", task_id=task_id, step=step, reason=reason)

    async def failed_continue(self, task_id: str | None, step: StepKind, error: str) -> None:
        """A failure that doesn't stop the task (e.g. a dither that didn't settle)."""
        await self._publish(
            SequencerStepFailed(task_id=task_id, step=step, error=error, handling="continue")
        )
        logger.warning(
            "sequencer.step_failed", task_id=task_id, step=step, error=error, handling="continue"
        )

    async def _await_bus(
        self,
        action: Callable[[], Awaitable[None]],
        device_id: str,
        success: tuple[str, ...],
        failure: tuple[str, ...],
        timeout: float,
    ) -> BaseEvent:
        """Subscribe, run *action*, then wait for a matching event for *device_id*.

        Subscribing first means events published synchronously inside the action are seen.
        Returns the success event; raises RuntimeError on a failure event or timeout.
        """
        q = self._host.bus.subscribe()
        try:
            await action()
            async with asyncio.timeout(timeout):
                while True:
                    event = await q.get()
                    if getattr(event, "device_id", None) != device_id:
                        continue
                    etype = getattr(event, "type", "")
                    if etype in success:
                        return cast(BaseEvent, event)
                    if etype in failure:
                        reason = getattr(event, "reason", None) or etype
                        raise RuntimeError(reason)
        except TimeoutError:
            raise RuntimeError(f"timed out after {timeout:.0f} s") from None
        finally:
            self._host.bus.unsubscribe(q)

    # ── Flat panel ─────────────────────────────────────────────────────────

    async def flat_panel_on(
        self, task_id: str | None, devices: LaneDevices, brightness: int | None
    ) -> None:
        """Cover closed, light on at *brightness* (null = as it is). Does nothing for
        what is already so, which makes it cheap to call before every frame."""
        fpm = self._state("flat_panel_manager")
        if devices.flat_panel_id is None or fpm is None:
            raise StepError("flat_panel", f"No flat panel for camera '{devices.camera_id}'")
        panel = devices.flat_panel_id
        try:
            status = await fpm.get_status(panel)
            if status.has_cover and status.cover != "closed":
                t0 = await self._started(
                    task_id, "flat_panel", Activity.FLAT_PANEL, f"Closing the cover of {panel}"
                )
                await fpm.close_cover(panel)
                await self._finished(task_id, "flat_panel", t0, {"panel": panel, "cover": "closed"})
            if status.has_light and (
                not status.light_on or (brightness is not None and status.brightness != brightness)
            ):
                t0 = await self._started(
                    task_id, "flat_panel", Activity.FLAT_PANEL, f"Lighting {panel}"
                )
                await fpm.set_light(panel, True, brightness)
                await self._finished(
                    task_id, "flat_panel", t0, {"panel": panel, "light": True, "brightness": brightness}
                )
        except StepError:
            raise
        except Exception as exc:
            raise StepError("flat_panel", f"Flat panel {panel} failed: {exc}") from exc

    async def flat_panel_off(self, task_id: str | None, devices: LaneDevices) -> None:
        """Light off, cover open. Runs when a task leaves the panel for any reason, so
        it reports instead of raising: an exception must not mask the original one."""
        fpm = self._state("flat_panel_manager")
        if devices.flat_panel_id is None or fpm is None:
            return
        panel = devices.flat_panel_id
        try:
            status = await fpm.get_status(panel)
            if status.has_light and status.light_on:
                await fpm.set_light(panel, False)
            if status.has_cover and status.cover != "open":
                await fpm.open_cover(panel)
        except Exception as exc:
            logger.error("sequencer.flat_panel_release_failed", panel=panel, error=str(exc))
            await self._publish(
                SequencerStepFailed(
                    task_id=task_id,
                    step="flat_panel",
                    error=f"Could not switch off / open flat panel {panel}: {exc}",
                    handling="continue",
                )
            )

    # ── Camera cooling ─────────────────────────────────────────────────────

    async def set_temperature(
        self, task_id: str | None, camera_id: str, temperature: float
    ) -> bool:
        """Turn the cooler on at *temperature*. False (and a skip event) if the camera
        has no cooling."""
        dm = self._state("device_manager")
        if dm is None:
            await self.skipped(task_id, "cooling", "no device manager")
            return False
        camera = dm.get_camera(camera_id)
        try:
            if (await camera.get_status()).temperature is None:
                await self.skipped(task_id, "cooling", f"{camera_id} has no cooling")
                return False
            t0 = await self._started(
                task_id, "cooling", Activity.COOLING, f"Cooling {camera_id} to {temperature:g} °C"
            )
            await camera.set_cooler(True, temperature)
        except Exception as exc:
            raise StepError("cooling", f"Could not set {camera_id} temperature: {exc}") from exc
        await self._finished(task_id, "cooling", t0, {"camera": camera_id, "target_c": temperature})
        return True

    async def wait_for_temperature(
        self, task_id: str | None, targets: dict[str, float]
    ) -> None:
        """Block until every camera in *targets* is within tolerance of its set point."""
        dm = self._state("device_manager")
        if dm is None or not targets:
            return
        cfg = self._host.settings
        t0 = await self._started(
            task_id, "cooling", Activity.COOLING, "Waiting for cameras to reach temperature"
        )
        deadline = time.monotonic() + cfg.cooling_timeout_min * 60
        while True:
            pending: list[str] = []
            for camera_id, target in targets.items():
                try:
                    temp = (await dm.get_camera(camera_id).get_status()).temperature
                except Exception as exc:
                    raise StepError("cooling", f"Could not read {camera_id} temperature: {exc}") from exc
                if temp is not None and abs(temp - target) > cfg.cooling_tolerance_c:
                    pending.append(f"{camera_id} {temp:.1f}/{target:g} °C")
            if not pending:
                break
            if time.monotonic() > deadline:
                raise StepError("cooling", "Cameras did not reach temperature: " + ", ".join(pending))
            await self._host.set_activity(Activity.COOLING, "Cooling: " + ", ".join(pending))
            await asyncio.sleep(COOLING_POLL_S)
        await self._finished(task_id, "cooling", t0, {"cameras": len(targets)})

    async def warm_cameras(self, temperature: float) -> None:
        """End of queue: set every cooled connected camera to *temperature*."""
        dm = self._state("device_manager")
        if dm is None:
            return
        for dev in dm.list_connected():
            if dev["kind"] != "camera":
                continue
            try:
                await self.set_temperature(None, dev["device_id"], temperature)
            except StepError as exc:
                logger.warning("sequencer.warm_failed", camera=dev["device_id"], error=str(exc))

    # ── Mount ──────────────────────────────────────────────────────────────

    async def unpark(self, mount_id: str | None) -> None:
        mm = self._state("mount_manager")
        if mount_id is None or mm is None:
            await self.skipped(None, "unpark", "no mount connected")
            return
        try:
            status = await mm.get_status(mount_id)
        except Exception as exc:
            raise StepError("unpark", f"Could not read mount status: {exc}") from exc
        if not status.is_parked:
            return
        t0 = await self._started(None, "unpark", Activity.UNPARKING, "Unparking mount")
        try:
            await mm.unpark(mount_id)
        except Exception as exc:
            raise StepError("unpark", f"Unpark failed: {exc}") from exc
        await self._finished(None, "unpark", t0)

    async def park(self, mount_id: str | None) -> None:
        mm = self._state("mount_manager")
        if mount_id is None or mm is None:
            await self.skipped(None, "park", "no mount connected")
            return
        await self.stop_guiding(None)
        t0 = await self._started(None, "park", Activity.PARKING, "Parking mount")
        try:
            await self._await_bus(
                lambda: mm.park(mount_id),
                mount_id,
                success=("mount.parked",),
                failure=("mount.operation_failed",),
                timeout=self._host.settings.park_timeout_s,
            )
        except Exception as exc:
            raise StepError("park", f"Park failed: {exc}") from exc
        await self._finished(None, "park", t0)

    async def ensure_tracking(self, mount_id: str | None, step: StepKind) -> None:
        """Turn tracking on if the mount is not tracking. A parked mount is left alone (it
        cannot track, and unparking is the runner's job); a mount that refuses fails *step*."""
        mm = self._state("mount_manager")
        if mount_id is None or mm is None:
            return
        try:
            status = await mm.get_status(mount_id)
            if status.is_parked or status.is_tracking:
                return
            await mm.set_tracking(mount_id, True, source="automation")
        except Exception as exc:
            raise StepError(step, f"Could not start tracking: {exc}") from exc
        logger.info("sequencer.tracking_enabled", mount_id=mount_id, step=step)

    async def slew(self, task: ImagingTask, target: ResolvedTarget, mount_id: str | None) -> None:
        mm = self._state("mount_manager")
        if mount_id is None or mm is None:
            raise StepError("slew", "No mount connected")
        await self.ensure_tracking(mount_id, "slew")
        assert target.ra is not None and target.dec is not None
        import astropy.units as u
        from astropy.coordinates import SkyCoord

        t0 = await self._started(task.id, "slew", Activity.SLEWING, f"Slewing to {target.name}")
        coord = SkyCoord(ra=target.ra * u.deg, dec=target.dec * u.deg, frame="icrs")
        try:
            await mm.set_target(mount_id, coord, name=target.name, source="sequencer")
            await self._await_bus(
                lambda: mm.slew(mount_id),
                mount_id,
                success=("mount.slew_completed",),
                failure=("mount.slew_aborted", "mount.operation_failed"),
                timeout=self._host.settings.slew_timeout_s,
            )
        except Exception as exc:
            raise StepError("slew", f"Slew to {target.name} failed: {exc}") from exc
        await self._finished(
            task.id, "slew", t0, {"ra": round(target.ra, 5), "dec": round(target.dec, 5)}
        )

    async def meridian_flip(self, task: ImagingTask, mount_id: str) -> bool:
        """Flip the mount. Returns False if the mount says no flip is needed."""
        mm = self._state("mount_manager")
        await self.ensure_tracking(mount_id, "meridian_flip")
        before = await mm.get_status(mount_id)
        t0 = await self._started(task.id, "meridian_flip", Activity.MERIDIAN_FLIP, "Meridian flip")
        try:
            await self._await_bus(
                lambda: mm.meridian_flip(mount_id),
                mount_id,
                success=("mount.meridian_flip_completed",),
                failure=("mount.slew_aborted", "mount.operation_failed"),
                timeout=self._host.settings.flip_timeout_s,
            )
        except ValueError as exc:
            if "No meridian flip needed" not in str(exc):
                raise StepError("meridian_flip", f"Meridian flip failed: {exc}") from exc
            await self.skipped(task.id, "meridian_flip", str(exc))
            return False
        except Exception as exc:
            raise StepError("meridian_flip", f"Meridian flip failed: {exc}") from exc
        after = await mm.get_status(mount_id)
        await self._finished(
            task.id,
            "meridian_flip",
            t0,
            {
                "pier_before": before.pier_side,
                "pier_after": after.pier_side,
                "hour_angle": round(after.hour_angle, 3) if after.hour_angle is not None else None,
            },
        )
        return True

    async def center(self, task: ImagingTask, target: ResolvedTarget, devices: LaneDevices) -> None:
        solve_manager = self._state("solve_manager")
        if solve_manager is None:
            await self.skipped(task.id, "center", "plate solving plugin not enabled")
            return
        if not hasattr(solve_manager, "center"):
            await self.skipped(task.id, "center", "plate solving plugin has no centering support")
            return
        if devices.mount_id is None or devices.camera_id is None:
            raise StepError("center", "Centering needs a connected mount and camera")
        assert target.ra is not None and target.dec is not None
        await self.ensure_tracking(devices.mount_id, "center")
        cfg = self._host.settings
        t0 = await self._started(task.id, "center", Activity.CENTERING, f"Centering {target.name}")
        try:
            result = await solve_manager.center(
                mount_id=devices.mount_id,
                camera_id=devices.camera_id,
                ra=target.ra,
                dec=target.dec,
                name=target.name,
                slew_first=False,  # the task setup (or the flip) has just slewed
                tolerance_arcsec=cfg.center_tolerance_arcsec,
                max_attempts=cfg.center_max_attempts,
                exposure_s=cfg.center_exposure_s,
                binning=cfg.center_binning,
            )
        except Exception as exc:
            raise StepError("center", f"Centering failed: {exc}") from exc
        details: StepDetails = {
            "attempts": len(result.attempts),
            "final_error_arcsec": (
                round(result.final_error_arcsec, 1)
                if result.final_error_arcsec is not None
                else None
            ),
        }
        if not result.success:
            stall = StallKind.CENTERING if result.failure == "no_solution" else None
            raise StepError(
                "center", result.message or "Centering did not succeed", stall_kind=stall
            )
        await self._finished(task.id, "center", t0, details)

    # ── Guiding ────────────────────────────────────────────────────────────

    def _guider(self) -> Guider | None:
        guider: Guider | None = self._state("guider")
        return guider

    def _settle(self) -> SettleParams:
        cfg = self._host.settings
        return SettleParams(
            pixels=cfg.guide_settle_pixels,
            time=cfg.guide_settle_time_s,
            timeout=cfg.guide_settle_timeout_s,
        )

    async def stop_guiding(self, task_id: str | None) -> None:
        guider = self._guider()
        if guider is None:
            return
        status = guider.status()
        if not status.connected or not status.active:
            return
        t0 = await self._started(task_id, "stop_guiding", None, "Stopping guiding")
        try:
            await guider.stop()
        except Exception as exc:
            await self.failed_continue(task_id, "stop_guiding", str(exc))
            return
        await self._finished(task_id, "stop_guiding", t0)

    async def start_guiding(self, task_id: str, mount_id: str | None = None) -> None:
        guider = self._guider()
        if guider is None:
            await self.skipped(
                task_id, "start_guiding", "no guider enabled (PHD2 or guide simulator)"
            )
            return
        if not guider.status().connected:
            raise StepError("start_guiding", f"The guider ({guider.name}) is not connected")
        await self.ensure_tracking(mount_id, "start_guiding")
        t0 = await self._started(
            task_id, "start_guiding", Activity.STARTING_GUIDING, "Starting guiding"
        )
        try:
            await guider.guide(self._settle(), wait_settle=True)
        except GuiderNotConnected as exc:
            raise StepError("start_guiding", f"The guider is not connected: {exc}") from exc
        except Exception as exc:
            raise StepError(
                "start_guiding", f"Guiding did not start or settle: {exc}", StallKind.GUIDING
            ) from exc
        await self._finished(task_id, "start_guiding", t0)

    def guiding_mark(self) -> float | None:
        """Start of a guiding-statistics window (None without a guider)."""
        guider = self._guider()
        return None if guider is None else guider.mark()

    def guiding_stats(self, mark: float | None) -> dict[str, Any]:
        """Guiding RMS / unguided time / losses since *mark*, as SequencerFrameSaved fields."""
        guider = self._guider()
        if mark is None or guider is None:
            return {}
        try:
            stats = guider.stats(mark)
        except Exception as exc:
            logger.warning("sequencer.guiding_stats_failed", error=str(exc))
            return {}
        return {
            "guide_rms_total": stats.rms_total,
            "unguided_s": stats.unguided_s,
            "guiding_losses": stats.losses,
        }

    async def record_guiding_in_fits(self, fits_path: str, guiding: dict[str, Any]) -> None:
        """Write the frame's guiding figures into its FITS header (best effort)."""
        if not guiding:
            return
        from astrolol.imaging.imager import add_fits_header_cards

        cards: dict[str, tuple[Any, str]] = {
            "GUIDLOST": (guiding["unguided_s"], "[s] time without active guiding"),
            "GUIDLOSN": (guiding["guiding_losses"], "times guiding was interrupted"),
        }
        if guiding.get("guide_rms_total") is not None:
            # A guider that does not know its pixel scale reports guide-camera pixels.
            guider = self._guider()
            try:
                in_pixels = guider is not None and not guider.status().pixel_scale
            except Exception:
                in_pixels = False
            unit = "[guide px]" if in_pixels else "[arcsec]"
            cards["GUIDRMS"] = (guiding["guide_rms_total"], f"{unit} total guiding RMS")
        try:
            await asyncio.to_thread(add_fits_header_cards, fits_path, cards)
        except Exception as exc:
            logger.warning(
                "sequencer.fits_guiding_cards_failed", fits_path=fits_path, error=str(exc)
            )

    async def dither(self, task_id: str) -> None:
        guider = self._guider()
        if guider is None:
            await self.skipped(task_id, "dither", "no guider enabled (PHD2 or guide simulator)")
            return
        if not guider.status().connected:
            await self.failed_continue(
                task_id, "dither", f"The guider ({guider.name}) is not connected"
            )
            return
        if not guider.health().guiding:
            await self.skipped(
                task_id, "dither", "guiding is down; restarting it will move the star anyway"
            )
            return
        cfg = self._host.settings
        t0 = await self._started(task_id, "dither", Activity.DITHERING, "Dithering")
        try:
            await guider.dither(cfg.dither_pixels, cfg.dither_ra_only, self._settle())
        except Exception as exc:
            await self.failed_continue(task_id, "dither", str(exc))
            return
        await self._finished(task_id, "dither", t0)

    # ── Autofocus ──────────────────────────────────────────────────────────

    async def autofocus(self, task: ImagingTask, devices: LaneDevices, reason: str) -> bool:
        """Run autofocus. Returns False when it can't run here (reported as skipped).

        A run that found no stars raises a StepError with stall_kind=AUTOFOCUS (the focuser
        is back at its last good position); other failures raise a plain StepError.
        """
        engine = self._state("autofocus_engine")
        if engine is None or not hasattr(engine, "focus"):
            await self.skipped(task.id, "autofocus", "autofocus plugin not enabled")
            return False
        if devices.focuser_id is None or devices.camera_id is None:
            await self.skipped(task.id, "autofocus", "no focuser in this camera's optical path")
            return False
        t0 = await self._started(task.id, "autofocus", Activity.FOCUSING, f"Autofocus ({reason})")
        try:
            run = await engine.focus(devices.camera_id, devices.focuser_id)
        except ValueError as exc:
            raise StepError("autofocus", f"Autofocus could not start: {exc}") from exc
        except Exception as exc:
            raise StepError("autofocus", f"Autofocus failed: {exc}") from exc
        if run.status != "completed":
            raise StepError(
                "autofocus",
                f"Autofocus failed: {run.error or run.status}",
                stall_kind=StallKind.AUTOFOCUS if getattr(run, "sky_problem", False) else None,
            )
        best = min((dp.fwhm for dp in run.data_points if dp.fwhm > 0), default=None)
        await self._finished(
            task.id,
            "autofocus",
            t0,
            {
                "reason": reason,
                "position": run.optimal_position,
                "best_fwhm": round(best, 2) if best is not None else None,
                "samples": len(run.data_points),
            },
        )
        return True

    async def frame_context(self, devices: LaneDevices) -> dict[str, Any]:
        """Altitude, hour angle, focuser position and sensor temperature, best effort —
        recorded with each frame (events, journal)."""
        ctx: dict[str, Any] = {}
        mm = self._state("mount_manager")
        dm = self._state("device_manager")
        if mm is not None and devices.mount_id is not None:
            try:
                st = await mm.get_status(devices.mount_id)
                alt, ha = getattr(st, "alt", None), getattr(st, "hour_angle", None)
                ctx["altitude"] = round(alt, 2) if alt is not None else None
                ctx["hour_angle"] = round(ha, 4) if ha is not None else None
            except Exception:
                pass
        if dm is not None and devices.focuser_id is not None:
            with contextlib.suppress(Exception):
                focuser_status = await dm.get_focuser(devices.focuser_id).get_status()
                ctx["focuser_position"] = focuser_status.position
        if dm is not None and devices.camera_id is not None:
            with contextlib.suppress(Exception):
                camera_status = await dm.get_camera(devices.camera_id).get_status()
                ctx["sensor_temperature"] = camera_status.temperature
        return ctx

    async def focuser_temperature(self, focuser_id: str | None) -> float | None:
        dm = self._state("device_manager")
        if focuser_id is None or dm is None:
            return None
        try:
            status = await dm.get_focuser(focuser_id).get_status()
        except Exception:
            return None
        temp = getattr(status, "temperature", None)
        return float(temp) if temp is not None else None

    # ── Imaging ────────────────────────────────────────────────────────────

    async def resolve_target(self, task: ImagingTask) -> ResolvedTarget:
        t0 = time.monotonic()
        try:
            resolved = await resolve_target(task.target, self._app)
        except TargetUnresolvable as exc:
            raise StepError("resolve_target", str(exc)) from exc
        if resolved.warning:
            await self.failed_continue(task.id, "resolve_target", resolved.warning)
        await self._finished(
            task.id,
            "resolve_target",
            t0,
            {
                "source": resolved.source,
                "ra": round(resolved.ra, 5) if resolved.ra is not None else None,
                "dec": round(resolved.dec, 5) if resolved.dec is not None else None,
            },
        )
        return resolved

    async def change_filter(self, task_id: str, devices: LaneDevices, filter_name: str) -> bool:
        """Returns True if the wheel actually moved, False if it was already there.

        Callers that trigger autofocus on a filter change (``autofocus_on_filter_change``)
        must only do so when this returns True — the cache that decides *whether* to call
        this (``_LaneState.current_filter``) gets invalidated on every sequencer resume,
        since a pause could have let something else touch the wheel, but most resumes
        never actually did.
        """
        fwm = self._state("filter_wheel_manager")
        if devices.filter_wheel_id is None or fwm is None:
            raise StepError("change_filter", f"No filter wheel for camera '{devices.camera_id}'")
        try:
            status = await fwm.get_status(devices.filter_wheel_id)
        except Exception as exc:
            raise StepError("change_filter", f"Could not read the filter wheel: {exc}") from exc
        names = status.filter_names or []
        if filter_name not in names:
            raise StepError(
                "change_filter",
                f"Filter '{filter_name}' is not in the wheel ({', '.join(names) or 'no names'})",
            )
        slot = names.index(filter_name) + 1
        if status.current_slot == slot:
            return False
        t0 = await self._started(
            task_id, "change_filter", Activity.CHANGING_FILTER, f"Filter → {filter_name}"
        )
        try:
            await fwm.select_filter(devices.filter_wheel_id, slot)
        except Exception as exc:
            raise StepError(
                "change_filter", f"Changing to filter '{filter_name}' failed: {exc}"
            ) from exc
        await self._finished(task_id, "change_filter", t0, {"filter": filter_name, "slot": slot})
        return True

    async def expose(self, task: ImagingTask, devices: LaneDevices, group: ExposureGroup) -> str:
        """Take one saved frame; returns the FITS path. Cancellation aborts the exposure."""
        im = self._state("imager_manager")
        if im is None or devices.camera_id is None:
            raise StepError("expose", "No camera connected")
        from astrolol.imaging.models import ExposureRequest

        req = ExposureRequest(
            duration=group.duration,
            gain=group.gain,
            binning=group.binning,
            frame_type=group.frame_type,
            save=True,
            object_name=task.target.name,
        )
        timeout = group.duration + self._host.settings.exposure_timeout_margin_s
        try:
            async with asyncio.timeout(timeout):
                result = await im.expose(devices.camera_id, req)
        except TimeoutError:
            raise StepError("expose", f"Exposure timed out after {timeout:.0f} s") from None
        except Exception as exc:
            raise StepError("expose", f"Exposure failed: {exc}") from exc
        return str(result.fits_path)
